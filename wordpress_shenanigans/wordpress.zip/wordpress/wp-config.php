<?php
/**
 * WordPressin perusasetukset.
 *
 * Tämä tiedosto sisältää seuraavat asetukset: MySQL-asetukset, Tietokantataulun etuliite,
 * henkilökohtaiset salausavaimet (Secret Keys), WordPressin kieli, ja ABSPATH. Löydät lisätietoja
 * Codex-sivulta {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php}. Saat MySQL-asetukset palveluntarjoajaltasi.
 *
 * Automaattinen wp-config.php-tiedoston luontityökalu käyttää tätä tiedostoa
 * asennuksen yhteydessä. Sinun ei tarvitse käyttää web-asennusta, vaan voit
 * tallentaa tämän tiedoston nimellä "wp-config.php" ja muokata allaolevia arvoja.
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL asetukset - Saat nämä tiedot palveluntarjoajaltasi ** //
/** WordPressin käyttämän tietokannan nimi */
define( 'DB_NAME', 'wordpressdb' );

/** MySQL-tietokannan käyttäjätunnus */
define( 'DB_USER', 'root' );

/** MySQL-tietokannan salasana */
define( 'DB_PASSWORD', 'sala' );

/** MySQL-palvelin */
define( 'DB_HOST', 'localhost' );

/** Tietokantatauluissa käytettävä merkistö. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Älä muuta tätä jos et ole varma. */
define('DB_COLLATE', 'utf8_swedish_ci');
define('FS_METHOD', 'direct');
/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Muuta nämä omiksi uniikeiksi lauseiksi!
 * Voit luoda nämä käyttämällä {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org palvelua}
 * Voit muuttaa nämä koska tahansa. Kaikki käyttäjät joutuvat silloin kirjautumaan uudestaan.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '*W F-r)&n7IO,h=IR}c-tfKbU.RJ47C8>DP2%5pR_S%LE1:d&i+m]Tov9i7=i-nS' );
define( 'SECURE_AUTH_KEY',  ')qRD&zL%HzTDRL#8Z^M(LS85$kvn_%i+Vonte@!d4^y]kplIu{r@Y<k+i2J7_#9S' );
define( 'LOGGED_IN_KEY',    '|+7Yl<wUsG,Fj85gsx,x| *Eti,CvkZ2+}UYUZxsPm?fo.1.uPz/~N7W84*d|G=#' );
define( 'NONCE_KEY',        ' o31I6pflT,VzY(w.|>l+_.n?8Wb;R.vB- eD{oAZM)i#{BO5yn?BzAe9NI79_5.' );
define( 'AUTH_SALT',        'dov%%z9j[=K$Nss?)G+.pgKcU$?-M gwWvD&(n?%@OSsUy|$Phxbg7:)kTHfe!lc' );
define( 'SECURE_AUTH_SALT', ' O*^YdK}eDzex/Xm2pJs,DqY_|lWugxC-d3T*_L-3j)}*;]=P>b ,6mL2:iCP9w7' );
define( 'LOGGED_IN_SALT',   '#%cQu] zy,gb0%(ce=/EE&}^=6^^YLvr.L(P*S_l/t#2_RP5trGi*.v8_2@d!C6p' );
define( 'NONCE_SALT',       '%]w7juH|mIEfgD;Lc 39nn<p[!=t`n:@{G&(XV#pIZ%,^tqnG?V0xw&S)Yv3yTZP' );
/**#@-*/

/**
 * WordPressin tietokantataulujen etuliite (Table Prefix).
 *
 * Samassa tietokannassa voi olla useampi WordPress-asennus, jos annat jokaiselle
 * eri tietokantataulujen etuliitteen. Sallittuja merkkejä ovat numerot, kirjaimet
 * ja alaviiva _.
 *
 */
$table_prefix = 'wp_';

/**
 * Kehittäjille: WordPressin debug-moodi.
 *
 * Muuta tämän arvoksi true jos haluat nähdä kehityksen ajan debug-ilmoitukset
 * Tämä on erittäin suositeltavaa lisäosien ja teemojen kehittäjille.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* Siinä kaikki, älä jatka pidemmälle! */

/** WordPress absolute path to the Wordpress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
